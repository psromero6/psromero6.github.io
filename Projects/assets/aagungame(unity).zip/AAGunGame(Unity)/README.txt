AAGuns is a simple shooter made in under 6 hours.

Download both AAGuns.exe and AAGuns_Data directory, place in the same directory, and run AAGuns.exe.

Move your gun turrent with the mouse and fire with Left Mouse button. Shoot the planes before they destroy your base!!